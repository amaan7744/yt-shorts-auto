
def generate_script(story):
    print("Generating script...")
    return f"Script based on: {story}"
