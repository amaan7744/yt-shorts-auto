
def scrape_story():
    print("Scraping story...")
    return "Sample true crime story."
