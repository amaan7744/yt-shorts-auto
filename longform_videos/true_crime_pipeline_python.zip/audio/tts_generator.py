
def generate_tts(script):
    print("Generating TTS audio...")
    return "output_audio.mp3"
