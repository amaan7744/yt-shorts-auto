
from dataclasses import dataclass

@dataclass
class Story:
    title: str
    content: str
