
def match_sfx(script):
    print("Matching sound effects...")
    return ["boom.wav"]
