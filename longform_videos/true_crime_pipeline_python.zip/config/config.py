
import os

class Config:
    YOUTUBE_API_KEY = os.getenv("YOUTUBE_API_KEY", "")
