
def assemble_visuals(script):
    print("Assembling visuals...")
    return ["scene1.png", "scene2.png"]
