
def generate_subtitles(audio_path):
    print("Generating subtitles...")
    return "subtitles.srt"
