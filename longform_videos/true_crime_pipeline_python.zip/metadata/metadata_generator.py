
def generate_metadata(script):
    print("Generating metadata...")
    return {"title": "True Crime Short", "description": script}
