
from research.scraper import scrape_story
from script.script_writer import generate_script
from audio.tts_generator import generate_tts
from visuals.visual_assembler import assemble_visuals
from subtitles.whisper_subtitles import generate_subtitles
from sfx.sfx_matcher import match_sfx
from render.renderer import render_video
from metadata.metadata_generator import generate_metadata
from upload.youtube_uploader import upload_video

def main():
    print("Starting True Crime Pipeline...")

    story = scrape_story()
    script = generate_script(story)
    audio_path = generate_tts(script)
    visuals = assemble_visuals(script)
    subtitles = generate_subtitles(audio_path)
    sfx = match_sfx(script)
    video_path = render_video(audio_path, visuals, subtitles, sfx)
    metadata = generate_metadata(script)
    upload_video(video_path, metadata)

    print("Pipeline complete.")

if __name__ == "__main__":
    main()
