
def upload_video(video_path, metadata):
    print("Uploading to YouTube...")
    print(f"Uploaded {video_path} with metadata {metadata}")
