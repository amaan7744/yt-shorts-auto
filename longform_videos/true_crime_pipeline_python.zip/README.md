
# True Crime Pipeline (Python Version)

Stages:
1. Research
2. Script Generation
3. TTS Audio
4. Visual Assembly
5. Subtitle Generation
6. SFX Matching
7. Rendering
8. Metadata Generation
9. YouTube Upload

Run:
    python pipeline.py
